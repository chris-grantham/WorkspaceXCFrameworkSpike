//
//  FrameworkB.h
//  FrameworkB
//
//  Created by Christopher Grantham on 21/11/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for FrameworkB.
FOUNDATION_EXPORT double FrameworkBVersionNumber;

//! Project version string for FrameworkB.
FOUNDATION_EXPORT const unsigned char FrameworkBVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkB/PublicHeader.h>


